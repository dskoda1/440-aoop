#include <vector>
#include <iostream>
using namespace std;


int main(){


  vector<int> a;
  a.push_back(4);
  a.push_back(9);

  cout << a << endl;

}
