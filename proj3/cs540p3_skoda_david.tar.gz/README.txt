David Skoda
B-00400675

Project 3
Submission date: 5/18/2016

Progress:
Shared pointer is complete, no memory errors
Interpolate consumes and processes strings with arguments
that arent manipulators.

