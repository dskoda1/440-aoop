#include "Map.hpp"
#include "assert.h"

#include <iostream>

using namespace std;
using namespace cs540;
int main(){


	//Begin testing of functionality
	{

		Map<int, int> * m = new cs540::Map<int, int>();
	

		Map<int, int>::Iterator i = m->begin();

		



	}
}
