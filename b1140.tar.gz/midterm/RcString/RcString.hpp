/*
 * This is a reference counted string implementation.  Two RcString objects
 * that have a common ancestor and contain the original string should point to
 * the same data object.  This provides very fast copies.
 *
 * You are not allowed to use std::string in this.
 */



#ifndef CS540_RC_STRING_HPP
#define CS540_RC_STRING_HPP


namespace cs540 {


class RcString {
    private:
        class RcString_data {
            friend class RcString;
            int ref_count;
        };
    public:
        // Public methods.
        ~RcString() {
            // Delete the data object if the ref count goes to 0.
            if (--m_data->ref_count == 0) {
                delete m_data;
            }
        }
    private:
        RcString_data *m_data;
};



}



#endif
